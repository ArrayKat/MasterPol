using MasterPolLibrary;

namespace MasterPolUnitTests;

[TestClass]
public class HighLevelTests
{
    

    [TestMethod]
    public void Test_count_1000000000_ThrowExeptionBigData()
    {
        int idTypeProduct = 2;
        int idTypeMaterial = 5;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = 1000000000;

        Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2)));
    }

    [TestMethod]
    public void Test_count_null_ThrowExeptionNull()
    {
        int idTypeProduct = 2;
        int idTypeMaterial = 5;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = Convert.ToInt32(null);

        Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2)));
    }

    [TestMethod]
    public void Test_param1_null_ThrowExeptionNull()
    {
        int idTypeProduct = 2;
        int idTypeMaterial = 5;
        double param1 = Convert.ToDouble( null);
        double param2 = 2.7;
        int count = 10;

        Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2)));
    }


    [TestMethod]
    public void Test_param2_null_ThrowExeptionNull()
    {
        int idTypeProduct = 2;
        int idTypeMaterial = 5;
        double param1 = 2.7;
        double param2 = Convert.ToDouble(null);
        int count = 10;

        Assert.ThrowsException<AssertFailedException>(() => Assert.ThrowsException<SystemException>(() => Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2)));
    }

    [TestMethod]
    public void Test_count_0_expectedNegativ1()
    {
        int idTypeProduct = 2;
        int idTypeMaterial = 5;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = 0;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }
    [TestMethod]
    public void Test_idTypeProduct_Negativ1_expectedNegativ1()
    {
        int idTypeProduct = -1;
        int idTypeMaterial = 5;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = 10;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void Test_idTypeMaterial_Negativ5_expectedNegativ1()
    {
        int idTypeProduct = 1;
        int idTypeMaterial = -5;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = 10;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void Test_param1_Negativ5point6_expectedNegativ1()
    {
        int idTypeProduct = 1;
        int idTypeMaterial = 5;
        double param1 = -5.6;
        double param2 = 2.7;
        int count = 10;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void Test_param2_Negativ2poin7_expectedNegativ1()
    {
        int idTypeProduct = 1;
        int idTypeMaterial = 5;
        double param1 = 5.6;
        double param2 = -2.7;
        int count = 10;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void Test_idTypeProduct_10isNotExist_expectedNegativ1()
    {
        int idTypeProduct = 10;
        int idTypeMaterial = 5;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = 10;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }

    [TestMethod]
    public void Test_idTypeMaterial_10isNotExist_expectedNegativ1()
    {
        int idTypeProduct = 1;
        int idTypeMaterial = 10;
        double param1 = 5.6;
        double param2 = 2.7;
        int count = 10;

        int expected = -1;
        int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

        Assert.AreEqual(expected, actual);
    }
}
