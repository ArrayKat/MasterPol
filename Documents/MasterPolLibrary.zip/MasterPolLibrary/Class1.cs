﻿namespace MasterPolLibrary
{
    public class Class1
    {
        public static int MathCountMaterial(int idTypeProduct, int idTypeMaterial, int count, double param1, double param2 ) { 
            double ratioTypeProduct =0, percentDefectMaterials =0;

            switch (idTypeProduct) {
                case 1: ratioTypeProduct = 2.35; break;
                case 2: ratioTypeProduct = 5.15; break;
                case 3: ratioTypeProduct = 4.34; break;
                case 4: ratioTypeProduct = 1.5; break;
               default: ratioTypeProduct = -1; break;
            }

            switch (idTypeMaterial) {
                case 1: percentDefectMaterials = 0.1; break;
                case 2: percentDefectMaterials = 0.95; break;
                case 3: percentDefectMaterials = 0.28; break;
                case 4: percentDefectMaterials = 0.55; break;
                case 5: percentDefectMaterials = 0.34; break;
               default: percentDefectMaterials = -1; break;
            }

            if (percentDefectMaterials != -1 && ratioTypeProduct != -1 && param1 > 0 && param2 > 0 && count>0)
            {
                double result = param1 * param2 * ratioTypeProduct * count;
                result += result * percentDefectMaterials;
                return Convert.ToInt32(result);
            }
            else {
                return -1;
            }
        }
    }
}
