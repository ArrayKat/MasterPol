﻿using System.Diagnostics.Metrics;
using MasterPolLibrary;

namespace MasterPolUnitTests
{
    [TestClass]
    public sealed class LowLevelTests
    {
        [TestMethod]
        public void Test_NormalData_count2087()
        {
            int idTypeProduct = 2;
            int idTypeMaterial = 5;
            double param1 = 5.6;
            double param2 = 2.7;
            int count = 20;

            int expected = 2087;
            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_NormalData_dontReturn0()
        {
            int idTypeProduct = 2;
            int idTypeMaterial = 5;
            double param1 = 5.6;
            double param2 = 2.7;
            int count = 20;

            int expected = 0;
            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.AreNotEqual(expected, actual);
        }

        [TestMethod]
        public void Test_param1_1000000_expexted_342654000()
        {
            int idTypeProduct = 2;
            int idTypeMaterial = 5;
            double param1 = 1000000;
            double param2 = 2.7;
            int count = 20;

            int expected = 372654000;
            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_param2_1000000_expexted_342654000()
        {
            int idTypeProduct = 2;
            int idTypeMaterial = 5;
            double param1 = 2.7;
            double param2 = 1000000;
            int count = 20;

            int expected = 372654000;
            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_Actual1_Equal_Actual2_true()
        {
            int idTypeProduct = 2;
            int idTypeMaterial = 5;
            double param1 = 2.7;
            double param2 = 5.2;
            int count = 20;

            
            int actual1 = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);
            int actual2 = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param2, param1);

            Assert.IsTrue(actual1 == actual2);
        }

        [TestMethod]
        public void Test_param1_int5_expected_406()
        {
            int idTypeProduct = 1;
            int idTypeMaterial = 3;
            int param1 = 5;
            double param2 = 2.7;
            int count = 10;

            int expected = 406;
            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_param2_int3_expected_668()
        {
            int idTypeProduct = 1;
            int idTypeMaterial = 3;
            double param1 = 7.4;
            int param2 = 3;
            int count = 10;

            int expected = 668;
            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void Test_isNotNull_true()
        {
            int idTypeProduct = 1;
            int idTypeMaterial = 3;
            double param1 = 7.4;
            int param2 = 3;
            int count = 10;

            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.IsNotNull(actual);
        }

        [TestMethod]
        public void Test_isReturnTypeInt_true()
        {
            int idTypeProduct = 1;
            int idTypeMaterial = 3;
            double param1 = 7.4;
            int param2 = 3;
            int count = 10;

            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.IsInstanceOfType(actual,typeof(int));
        }

        [TestMethod]
        public void Test_isReturnTypeNotDouble_true()
        {
            int idTypeProduct = 1;
            int idTypeMaterial = 3;
            double param1 = 7.4;
            int param2 = 3;
            int count = 10;

            int actual = Class1.MathCountMaterial(idTypeProduct, idTypeMaterial, count, param1, param2);

            Assert.IsNotInstanceOfType(actual, typeof(double));
        }
    }
}
